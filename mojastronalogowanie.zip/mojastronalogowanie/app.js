import express from "express";
import session from "express-session";
import { User, sequelize } from "./models.js";
import bcrypt from "bcrypt";
import path from "path";
import { fileURLToPath } from "url";



const app = express();
const PORT = 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
  secret: "my_secret_key",
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 3600000 }
}));

sequelize.sync();

// Middleware to check if user is authenticated
function checkAuth(req, res, next) {
  if (req.session.userId) {
    next();
  } else {
    res.redirect("/login");
  }
}



app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "register.html"));
});

app.post("/register", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.send("Wszystkie pola wymagane!");

  const existingUser = await User.findOne({ where: { username } });
  if (existingUser) return res.send("Użytkownik już istnieje.");

  const hash = await bcrypt.hash(password, 10);
  await User.create({ username, password: hash });
  res.redirect("/login");
});


app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "login.html"));
});

app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ where: { username } });
  if (!user) return res.send("Nieprawidłowe dane logowania.");

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.send("Nieprawidłowe dane logowania.");

  req.session.userId = user.id;
  res.redirect("/dashboard");
});

app.get("/dashboard", checkAuth, async (req, res) => {
  res.sendFile(path.join(__dirname, "views", "dashboard.html"));
});


app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});


app.get("/", (req, res) => {
  res.redirect("/login");
});

app.listen(PORT, () => {
  console.log(`Serwer działa na http://localhost:${PORT}`);
});