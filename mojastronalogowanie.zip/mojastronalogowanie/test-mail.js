
const crypto = require("crypto");
const nodemailer = require("nodemailer");

app.post("/register", async (req, res) => {
  const { username, email, password } = req.body;

  try {
    const verificationToken = crypto.randomBytes(32).toString("hex");

    const newUser = await User.create({
      username,
      email,
      password,
      verificationToken
    });


    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "TWOJEMAIL@gmail.com",
        pass: "TWOJEHASLO"
      }
    });

    const verificationLink = `http://localhost:3000/verify?token=${verificationToken}`;
    const mailOptions = {
      from: "TWOJEMAIL@gmail.com",
      to: email,
      subject: "Weryfikacja konta",
      html: `<p>Kliknij link, aby zweryfikować konto: <a href="${verificationLink}">Zweryfikuj</a></p>`
    };

    await transporter.sendMail(mailOptions);
    res.send("Użytkownik zarejestrowany. Sprawdź e-mail.");
  } catch (error) {
    console.error("Błąd rejestracji:", error);
    res.status(500).send("Rejestracja nie powiodła się.");
  }
});